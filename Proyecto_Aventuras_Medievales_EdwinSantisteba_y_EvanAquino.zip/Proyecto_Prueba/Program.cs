﻿using System;

class SimuladorAventura
{
    static Random rng = new Random();

    static void Main(string[] args)
    {
        // Datos del jugador
        string nombre;
        int vida = 0, poder = 0, enemigosDerrotados = 0;
        string clase;

        // Elección del personaje
        Console.WriteLine("Bienvenido al Simulador de Aventuras");
        Console.Write("Ingresa el nombre de tu aventurero: ");
        nombre = Console.ReadLine();

        Console.WriteLine("\nElige tu personaje:");
        Console.WriteLine("1. Mago (100 HP, 20 Ataque)");
        Console.WriteLine("2. Caballero (70 HP, 30 Ataque)");
        Console.WriteLine("3. Arquera (85 HP, 25 Ataque)");
        Console.Write("Opción: ");
        string eleccion = Console.ReadLine();

        switch (eleccion)
        {
            case "1":
                clase = "Mago";
                vida = 100;
                poder = 20;
                break;
            case "2":
                clase = "Caballero";
                vida = 70;
                poder = 30;
                break;
            case "3":
                clase = "Arquera";
                vida = 85;
                poder = 25;
                break;
            default:
                Console.WriteLine("Opción inválida, serás un Mago por defecto.");
                clase = "Mago";
                vida = 100;
                poder = 20;
                break;
        }

        string mapaActual = "";
        bool rendirse = false;

        // Bucle del juego
        while (vida > 0 && enemigosDerrotados < 3 && !rendirse)
        {
            Console.WriteLine($"\n--- Menú Principal ---");
            Console.WriteLine($"Personaje: {clase}");
            Console.WriteLine($"Vida: {vida}");
            Console.WriteLine($"Poder de ataque: {poder}");
            Console.WriteLine($"Enemigos derrotados: {enemigosDerrotados}");
            Console.WriteLine("1. Escoger camino");
            Console.WriteLine("2. Continuar aventura");
            Console.WriteLine("3. Rendirse");
            Console.Write("Opción: ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    mapaActual = EscogerMapa();
                    break;
                case "2":
                    if (mapaActual == "")
                    {
                        Console.WriteLine("Debes escoger un camino primero.");
                    }
                    else
                    {
                        Combate(ref vida, ref poder, ref enemigosDerrotados, mapaActual);
                    }
                    break;
                case "3":
                    rendirse = true;
                    break;
                default:
                    Console.WriteLine("Opción inválida.");
                    break;
            }
        }

        // Final del juego
        if (vida <= 0)
            Console.WriteLine("\nTu personaje ha muerto. ¡Game Over!");
        else if (enemigosDerrotados >= 3)
            Console.WriteLine("\n¡Has derrotado a todos los enemigos y escapaste victorioso!");
        else
            Console.WriteLine("\nDecidiste rendirte. Fin de la aventura.");
    }

    static string EscogerMapa()
    {
        Console.WriteLine("\n--- Encrucijada ---");
        Console.WriteLine("Elige un camino:");
        Console.WriteLine("1. Bosque oscuro");
        Console.WriteLine("2. Cueva sombría");
        Console.WriteLine("3. Camino de piedra");
        Console.Write("Opción: ");
        string camino = Console.ReadLine();

        return camino switch
        {
            "1" => "Bosque oscuro",
            "2" => "Cueva sombría",
            "3" => "Camino de piedra",
            _ => "Bosque oscuro"
        };
    }

    static void Combate(ref int vida, ref int poder, ref int enemigosDerrotados, string mapa)
    {
        string nombreEnemigo = "";
        int vidaEnemigo = 0;
        int ataqueMin = 0;
        int ataqueMax = 0;

        if (enemigosDerrotados == 0)
        {
            nombreEnemigo = "Bandido";
            vidaEnemigo = 20;
            ataqueMin = 1;
            ataqueMax = 5;
        }
        else if (enemigosDerrotados == 1)
        {
            nombreEnemigo = "Monstruo";
            vidaEnemigo = 25;
            ataqueMin = 5;
            ataqueMax = 10;
        }
        else
        {
            nombreEnemigo = "Jefe Final";
            vidaEnemigo = 70;
            ataqueMin = 10;
            ataqueMax = 20;
        }

        Console.WriteLine($"\n¡Un {nombreEnemigo} aparece!");

        bool enCombate = true;
        if (mapa == "Cueva sombría")
        {
            int golpe = rng.Next(ataqueMin, ataqueMax + 1);
            vida -= golpe;
            Console.WriteLine($"¡El enemigo ataca primero y te hace {golpe} de daño!");
        }

        while (vidaEnemigo > 0 && vida > 0 && enCombate)
        {
            Console.WriteLine($"\nTu vida: {vida} | Vida del {nombreEnemigo}: {vidaEnemigo}");
            Console.WriteLine("1. Luchar");
            Console.WriteLine("2. Huir (-10 vida)");
            Console.Write("Opción: ");
            string accion = Console.ReadLine();

            if (accion == "1")
            {
                vidaEnemigo -= poder;
                Console.WriteLine($"Atacas al {nombreEnemigo} y le haces {poder} de daño.");
                if (vidaEnemigo > 0)
                {
                    int contraataque = rng.Next(ataqueMin, ataqueMax + 1);
                    vida -= contraataque;
                    Console.WriteLine($"El {nombreEnemigo} te ataca y te hace {contraataque} de daño.");
                }
            }
            else if (accion == "2")
            {
                vida -= 10;
                Console.WriteLine("Huiste del combate. Pierdes 10 puntos de vida.");
                enCombate = false;
            }
            else
            {
                Console.WriteLine("Opción inválida.");
            }
        }

        if (vidaEnemigo <= 0)
        {
            enemigosDerrotados++;
            Console.WriteLine($"\n¡Has derrotado al {nombreEnemigo}!");

            // Cofre misterioso
            Console.WriteLine("Aparece un cofre misterioso. ¿Deseas abrirlo? (s/n)");
            string abrir = Console.ReadLine().ToLower();

            if (abrir == "s")
            {
                int resultado = rng.Next(1, 4); // 1: energía, 2: poder, 3: veneno
                if (mapa == "Camino de piedra" && rng.Next(1, 5) == 1)
                {
                    Console.WriteLine("El cofre está vacío.");
                }
                else
                {
                    switch (resultado)
                    {
                        case 1:
                            vida += 10;
                            Console.WriteLine("¡Recuperaste 10 puntos de salud!");
                            break;
                        case 2:
                            poder += 7;
                            Console.WriteLine("¡Tu poder de ataque aumentó en 7 puntos!");
                            break;
                        case 3:
                            vida -= 5;
                            Console.WriteLine("¡Era veneno! Pierdes 5 puntos de salud.");
                            break;
                    }
                }
            }
        }
    }
}
